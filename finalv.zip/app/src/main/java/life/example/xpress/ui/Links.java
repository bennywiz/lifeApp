package life.example.xpress.ui;

public class Links {

    public static final String  sendservice = "https://lifexpress.bi/scripts/mailsend.php";
}
